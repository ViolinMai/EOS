***************
 Python HOWTOs
***************

Python HOWTOs are documents that cover a single, specific topic,
and attempt to cover it fairly completely. Modelled on the Linux
Documentation Project's HOWTO collection, this collection is an
effort to foster documentation that's more detailed than the
Python Library Reference.

Currently, the HOWTOs are:

.. toctree::
   :maxdepth: 1

   cporting.rst
   curses.rst
   descriptor.rst
   gdb_helpers.rst
   enum.rst
   functional.rst
   logging.rst
   logging-cookbook.rst
   regex.rst
   sockets.rst
   sorting.rst
   unicode.rst
   urllib2.rst
   argparse.rst
   ipaddress.rst
   instrumentation.rst
   perf_profiling.rst
   annotations.rst
   isolating-extensions.rst
   mro.rst
